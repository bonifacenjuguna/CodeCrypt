const { Markup } = require('telegraf');
const style = require('../keyboards/buttonStyle');
const repoCache = require('../lib/repoCache');
const requireConnected = require('../lib/requireConnected');
const format = require('../lib/format');
const inline = require('../keyboards/inline');
const bbtb = require('../keyboards/bbtb');
const config = require('../config');
const pins = require('../lib/pins');
const tags = require('../lib/tags');
const ephemeral = require('../lib/ephemeral');
const savedViews = require('../lib/savedViews');
const { safeEditMessageText } = require('../lib/safeEdit');

// Simple in-memory view-state per user (filter/sort/page) — not sensitive,
// fine to keep in process memory; resets on restart which is harmless here.
const viewState = new Map();

function getState(telegramId) {
  if (!viewState.has(telegramId)) {
    viewState.set(telegramId, { filterType: 'all', filterValue: null, sort: 'updated', page: 1, initialized: false, savedViewId: null });
  }
  return viewState.get(telegramId);
}

async function applyFilterSort(repos, state, telegramId, activeView) {
  let filtered = repos;
  if (activeView) {
    // Smart Folder active — its saved clauses replace the simple
    // filterType chain entirely (they're two different filtering systems;
    // mixing them silently would be confusing about which one "won").
    filtered = await savedViews.apply(telegramId, activeView, repos);
  } else {
    if (state.filterType === 'public') filtered = repos.filter((r) => !r.private);
    if (state.filterType === 'private') filtered = repos.filter((r) => r.private);
    if (state.filterType === 'forks') filtered = repos.filter((r) => r.fork);
    // #9 — has-license / no-license filter. license.key === 'other' or
    // spdx_id === 'NOASSERTION' both mean GitHub couldn't confidently detect
    // a real license, treated the same as "no license" everywhere else in
    // the bot (see format.repoCard).
    if (state.filterType === 'haslicense') {
      filtered = repos.filter((r) => r.license && r.license.spdx_id && r.license.spdx_id !== 'NOASSERTION');
    }
    if (state.filterType === 'nolicense') {
      filtered = repos.filter((r) => !r.license || !r.license.spdx_id || r.license.spdx_id === 'NOASSERTION');
    }
    if (state.filterType === 'language') filtered = repos.filter((r) => (r.language || 'None') === state.filterValue);
    if (state.filterType === 'tag') {
      const repoNames = new Set(await tags.reposWithTag(telegramId, Number(state.filterValue)));
      filtered = repos.filter((r) => repoNames.has(r.name));
    }
  }

  const sorted = [...filtered];
  if (state.sort === 'updated') sorted.sort((a, b) => new Date(b.updated_at) - new Date(a.updated_at));
  if (state.sort === 'name') sorted.sort((a, b) => a.name.localeCompare(b.name));
  if (state.sort === 'stars') sorted.sort((a, b) => b.stargazers_count - a.stargazers_count);
  if (state.sort === 'created') sorted.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  if (state.sort === 'language') sorted.sort((a, b) => (a.language || 'zzz').localeCompare(b.language || 'zzz'));

  return sorted;
}

const SORT_LABELS = { updated: 'Recently Updated', name: 'Name (A-Z)', stars: 'Most Stars', created: 'Recently Created', language: 'Dominant Language (A-Z)' };

async function filterLabel(state, telegramId, activeView) {
  if (activeView) return `📁 ${activeView.name}`;
  if (state.filterType === 'all') return 'All';
  if (state.filterType === 'public') return '🌐 Public';
  if (state.filterType === 'private') return '🔒 Private';
  if (state.filterType === 'forks') return '🍴 Forks';
  if (state.filterType === 'haslicense') return '⚖️ Has License';
  if (state.filterType === 'nolicense') return '🚫 No License';
  if (state.filterType === 'language') return `💻 ${state.filterValue}`;
  if (state.filterType === 'tag') {
    const allTags = await tags.listTags(telegramId);
    const t = allTags.find((x) => x.id === Number(state.filterValue));
    return t ? `🏷️ ${t.emoji} ${t.name}` : '🏷️ Tag';
  }
  return 'All';
}

/**
 * Renders one repo using the locked bot-wide card format (see
 * format.repoCard). Kept as its own export (rather than every screen
 * calling format.repoCard directly) so Pinned and any future screen render
 * identically to My Repos with one shared call.
 *
 * Note: a prior version of this took a `ctx` that was never actually in
 * scope (masked by a surrounding try/catch), which silently broke the
 * per-repo language-breakdown lookup on every call. The new card format
 * doesn't need that lookup at all — it shows repo.language directly — so
 * this version has no hidden dependency on caller scope.
 */
function renderRepoLine(r, { pinned = false, tagLine = '', sizeBytes } = {}) {
  return format.repoCard(r, { pinned, tagLine, sizeBytes, partialHealthCheck: true });
}

/** Builds the 🏷️ tag-chip line for a repo, if it has any tags. */
function tagLineFor(repoName, tagMap) {
  const repoTags = tagMap[repoName];
  if (!repoTags || repoTags.length === 0) return '';
  return `🏷️ ${format.escapeMd(repoTags.map((t) => `${t.emoji} ${t.name}`).join(' · '))}`;
}

async function showMyRepos(ctx, { edit = false } = {}) {
  const token = await requireConnected(ctx);
  if (!token) return;

  const telegramId = ctx.from.id;
  const state = getState(telegramId);

  if (!state.initialized) {
    state.initialized = true;
    try {
      const defaultsLib = require('../lib/defaults');
      const d = await defaultsLib.getDefaults(telegramId);
      if (d) {
        state.sort = d.default_sort || 'updated';
        state.filterType = d.default_filter || 'all';
      }
    } catch (_) { /* best-effort — fall back to hardcoded defaults */ }
  }

  const allRepos = await repoCache.getRepos(ctx.from.id, token);

  // Smart Folders (saved views) — resolved once per load so applyFilterSort
  // and filterLabel agree on the same view without querying twice.
  let activeView = null;
  if (state.savedViewId) {
    activeView = await savedViews.get(telegramId, state.savedViewId);
    if (!activeView) state.savedViewId = null; // deleted elsewhere — fall back silently
  }

  const filtered = await applyFilterSort(allRepos, state, telegramId, activeView);

  const perPage = config.REPOS_PER_PAGE;
  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  state.page = Math.min(state.page, totalPages);
  const pageRepos = filtered.slice((state.page - 1) * perPage, state.page * perPage);

  const fLabel = await filterLabel(state, telegramId, activeView);
  let text = `${format.sectionHeader('Repositories', `${allRepos.length} total`)}\n`;
  text += `  Filter: ${format.escapeMd(fLabel)} · Sort: ${format.escapeMd(SORT_LABELS[state.sort])}\n\n`;

  if (pageRepos.length === 0) {
    text += format.escapeMd(`No repos match filter "${fLabel}".`);
  } else {
    const [pinList, tagMap, treeStatsResults] = await Promise.all([
      pins.list(telegramId),
      tags.tagsForRepos(telegramId, pageRepos.map((r) => r.name)),
      // Real size, not GitHub's lagging cache — matches Repo View's
      // behavior. Only fetched for the 3 repos on
      // THIS page, not the whole list, so pagination keeps this cheap —
      // each page load costs one extra tree call per visible repo, not per
      // repo you own.
      Promise.all(pageRepos.map((r) =>
        repoCache.getTreeStats(telegramId, r.owner.login, r.name, token).catch(() => null)
      )),
    ]);
    const pinnedSet = new Set(pinList.map((p) => p.repo_name));
    const sizeByRepo = new Map(pageRepos.map((r, i) => [r.name, treeStatsResults[i]]));

    const cards = pageRepos.map((r) => {
      const stats = sizeByRepo.get(r.name);
      return renderRepoLine(r, {
        pinned: pinnedSet.has(r.name),
        tagLine: tagLineFor(r.name, tagMap),
        sizeBytes: stats ? stats.sizeBytes : undefined,
      });
    });
    text += cards.join(`\n${format.CARD_DIVIDER}\n`);
    text += `\n\nPage ${state.page} of ${totalPages}`;
  }

  const keyboard = inline.repoList(pageRepos, state.page, totalPages);

  if (edit) {
    const kb = { parse_mode: 'MarkdownV2', ...keyboard };
    if (await safeEditMessageText(ctx, text, kb)) return;
  }
  // 📁 Smart Folders picker — sent above the list, fresh loads only (not
  // edit-in-place refreshes), same best-effort shape as Recently Viewed
  // below. This is what Bulk Actions' "find it above My Repos" message
  // (shown after saving a Smart Folder) refers to.
  try {
    const views = await savedViews.list(telegramId);
    if (views.length) {
      const style = require('../keyboards/buttonStyle');
      const { Markup } = require('telegraf');
      const rows = [];
      for (let i = 0; i < views.length; i += 2) {
        rows.push(views.slice(i, i + 2).map((v) =>
          style.callback(`${activeView && v.id === activeView.id ? '✅ ' : ''}📁 ${v.name}`, `savedview:apply:${v.id}`, style.BLUE)
        ));
      }
      if (activeView) rows.push([style.callback('❌ Exit Smart Folder', 'savedview:exit', style.BLUE)]);
      await ctx.reply('📁 *Smart Folders*', { parse_mode: 'MarkdownV2', ...Markup.inlineKeyboard(rows) });
    }
  } catch (_) { /* best-effort — never blocks the main list */ }
  // Reply keyboard (BBTB) and inline keyboard can't share one message —
  // send the BBTB once via a tiny marker message, then content with only inline.
  await ephemeral.sendEphemeral(ctx, '📁 My Repos', bbtb.myRepos);
  await ctx.reply(text, { parse_mode: 'MarkdownV2', ...keyboard });
  // Surprise feature — recently viewed quick-access, best-effort, only
  // shown on the fresh (non-edit) load so it doesn't reappear on every
  // filter/sort/page tweak
  try {
    const recentlyViewed = require('../lib/recentlyViewed');
    const recent = await recentlyViewed.recent(telegramId, 5);
    if (recent.length) {
      const style = require('../keyboards/buttonStyle');
      const { Markup } = require('telegraf');
      await ctx.reply(
        '🕐 Recently viewed:',
        Markup.inlineKeyboard(recent.map((name) => [style.callback(`📦 ${name}`, `repo:${name}`, style.BLUE)]))
      );
    }
  } catch (_) { /* best-effort, never blocks the main list */ }
}

async function showStats(ctx) {
  const token = await requireConnected(ctx);
  if (!token) return;

  const allRepos = await repoCache.getRepos(ctx.from.id, token);

  if (allRepos.length === 0) {
    await ctx.reply('📊 Stats\n\nYou don\u2019t have any repos yet — create one to see stats here.');
    return;
  }

  const publicCount = allRepos.filter((r) => !r.private).length;
  const privateCount = allRepos.length - publicCount;
  const totalStars = allRepos.reduce((sum, r) => sum + (r.stargazers_count || 0), 0);

  const langCounts = {};
  for (const r of allRepos) {
    if (!r.language) continue;
    langCounts[r.language] = (langCounts[r.language] || 0) + 1;
  }
  const topLangEntry = Object.entries(langCounts).sort((a, b) => b[1] - a[1])[0];
  const topLanguage = topLangEntry ? `${topLangEntry[0]} (${topLangEntry[1]} repo${topLangEntry[1] === 1 ? '' : 's'})` : 'No language data';

  const mostActive = [...allRepos].sort((a, b) => new Date(b.pushed_at || b.updated_at) - new Date(a.pushed_at || a.updated_at))[0];
  const oldest = [...allRepos].sort((a, b) => new Date(a.created_at) - new Date(b.created_at))[0];

  // #8 — size trend. Uses GitHub's own repo.size field (already on every
  // repo object here, no extra fetch) rather than the real tree-based size
  // used elsewhere — summing real tree sizes across an entire account would
  // mean one tree fetch per repo just to render Stats, which isn't worth it
  // for a trend line that only needs to be roughly right, not exact.
  const sizeSnapshot = require('../lib/sizeSnapshot');
  const totalBytes = allRepos.reduce((sum, r) => sum + (r.size || 0) * 1024, 0);
  const previous = await sizeSnapshot.getPrevious(ctx.from.id).catch(() => null);
  await sizeSnapshot.save(ctx.from.id, totalBytes).catch(() => {});
  let trendLine = '';
  if (previous) {
    const delta = totalBytes - Number(previous.total_bytes);
    if (Math.abs(delta) >= 1024) { // don't show noise under 1KB
      const arrow = delta > 0 ? '📈' : '📉';
      const sign = delta > 0 ? '\\+' : '\\-'; // MarkdownV2: escape the reserved +/- character itself
      trendLine = `▸ ${arrow} ${sign}${format.escapeMd(format.formatBytes(Math.abs(delta)))} since ${format.escapeMd(format.relativeTime(previous.snapshotted_at))}\n`;
    }
  }
  // Rolling 30-day sparkline, one data point per calendar day
  // (size_snapshot_history), alongside the single prior-vs-now delta.
  let sparkLine = '';
  try {
    const history = await sizeSnapshot.getHistory(ctx.from.id, 30);
    if (history.length >= 3) {
      const spark = sizeSnapshot.sparkline(history.map((h) => Number(h.total_bytes)));
      sparkLine = `▸ 📊 30d trend: ${spark}\n`;
    }
  } catch (_) { /* best-effort */ }

  const text =
    `${format.sectionHeader('Stats', `${allRepos.length} total`)}\n\n` +
    `▸ 🌐 Public: ${publicCount}  ·  🔒 Private: ${privateCount}\n` +
    `▸ ⭐ Total stars: ${totalStars}\n` +
    `▸ 💻 Top language: ${format.escapeMd(topLanguage)}\n` +
    `▸ 💾 Total size: ${format.escapeMd(format.formatBytes(totalBytes))}\n` +
    trendLine +
    sparkLine +
    `\n📌 *Most active repo*\n` +
    `${format.escapeMd(mostActive.name)} · 🕒 ${format.escapeMd(format.relativeTime(mostActive.pushed_at || mostActive.updated_at))}\n\n` +
    `🕰️ *Oldest repo*\n` +
    `${format.escapeMd(oldest.name)} · 📅 ${format.escapeMd(format.relativeTime(oldest.created_at))}`;

  await ctx.reply(text, {
    parse_mode: 'MarkdownV2',
    ...Markup.inlineKeyboard([
      [style.callback(`📦 Open ${mostActive.name}`, `repo:${mostActive.name}`, style.BLUE)],
      [style.callback('⬅️ Back', 'repos:back', style.BLUE)],
    ]),
  });
}

async function showFilterMenu(ctx) {
  // Sent as a brand-new message (not an edit) — a BBTB tap has no prior
  // bot message to edit, so editing directly would fail with Telegram's
  // "400: message can't be edited" error. The callback handler in bot.js
  // edits THIS fresh message instead, so that edit is always safe.
  await ctx.reply('🔎 *Filter repositories by:*', {
    parse_mode: 'MarkdownV2',
    ...inline.filterMenu,
  });
}

async function showSortMenu(ctx) {
  await ctx.reply('↕️ *Sort repositories by:*', {
    parse_mode: 'MarkdownV2',
    ...inline.sortMenu,
  });
}

async function showLanguageFilterMenu(ctx) {
  const token = await requireConnected(ctx);
  if (!token) return;
  const allRepos = await repoCache.getRepos(ctx.from.id, token);

  const counts = {};
  for (const r of allRepos) {
    const lang = r.language || 'None';
    counts[lang] = (counts[lang] || 0) + 1;
  }
  const entries = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 10);

  const rows = entries.map(([lang, count]) => [
    style.callback(`${lang} (${count})`, `filter:lang:${lang}`),
  ]);
  rows.push([style.callback('📊 Language Overview', 'filter:langoverview', style.BLUE)]);
  rows.push([style.callback('⬅️ Back', 'repos:back', style.BLUE)]);

  await ctx.reply('💻 Filter by language:', Markup.inlineKeyboard(rows));
}

async function showLanguageOverview(ctx) {
  const token = await requireConnected(ctx);
  if (!token) return;
  const allRepos = await repoCache.getRepos(ctx.from.id, token);

  const counts = {};
  for (const r of allRepos) {
    const lang = r.language || 'Other';
    counts[lang] = (counts[lang] || 0) + 1;
  }
  const total = allRepos.length || 1;
  const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);

  const barWidth = 10;
  let text = `📊 *Your Languages* — ${total} repos\n\n`;
  for (const [lang, count] of sorted.slice(0, 8)) {
    const pct = Math.round((count / total) * 100);
    const filled = Math.round((pct / 100) * barWidth);
    const bar = '█'.repeat(filled) + '░'.repeat(barWidth - filled);
    text += `${format.escapeMd(lang.padEnd(12))} ${count} repos  ${bar}  ${pct}%\n`;
  }

  await ctx.reply(text, {
    parse_mode: 'MarkdownV2',
    ...Markup.inlineKeyboard([[style.callback('⬅️ Back to Filter', 'repos:langfiltermenu', style.BLUE)]]),
  });
}

async function showTagFilterMenu(ctx) {
  const userTags = await tags.listTags(ctx.from.id);
  if (userTags.length === 0) {
    await ctx.reply('🏷️ You don\u2019t have any tags yet — create one from a repo\u2019s Tags screen first.');
    return;
  }
  const rows = userTags.map((t) => [style.callback(`${t.emoji} ${t.name} (${t.repo_count})`, `filter:tag:${t.id}`)]);
  rows.push([style.callback('⬅️ Back', 'repos:back', style.BLUE)]);
  await ctx.reply('🏷️ Filter by tag:', Markup.inlineKeyboard(rows));
}

function setFilter(telegramId, type, value = null) {
  const state = getState(telegramId);
  state.filterType = type;
  state.filterValue = value;
  state.savedViewId = null; // choosing a plain filter exits any active Smart Folder
  state.page = 1;
}

function setSort(telegramId, sort) {
  const state = getState(telegramId);
  state.sort = sort;
  state.page = 1;
}

function setPage(telegramId, page) {
  getState(telegramId).page = page;
}

function setSavedView(telegramId, viewId) {
  const state = getState(telegramId);
  state.savedViewId = viewId;
  state.page = 1;
}

function clearSavedView(telegramId) {
  const state = getState(telegramId);
  state.savedViewId = null;
  state.page = 1;
}

module.exports = {
  showMyRepos,
  showStats,
  showFilterMenu,
  showSortMenu,
  showLanguageFilterMenu,
  showLanguageOverview,
  showTagFilterMenu,
  setFilter,
  setSort,
  setPage,
  setSavedView,
  clearSavedView,
  getState,
  renderRepoLine,
  tagLineFor,
};
